import __init__ as test

resultado = test.suma(2,3)

print(resultado)

a = [   [-1, 0, 1],
        [7, (3/2), -(13/2)],
        [3, (1/2), -(5/2)]]
b = [[11],
        [-4],
        [10]]

resultado= test.multmat(a, b)