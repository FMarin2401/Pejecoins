import __init__ as test

resultado = test.suma(2,3)

print(resultado)